/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: abdel-ke <abdel-ke@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/22 18:15:05 by abdel-ke          #+#    #+#             */
/*   Updated: 2021/03/22 18:29:06 by abdel-ke         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include "../src/libft/libft.h"

void	check_quote(char *line)
{
	int cp =0;

	while (*line)
	{
		if (*line == '"' && line[-1] != '\\')
			cp++;
		line++;
	}
	printf("|%d|\n", cp);
	if (cp % 2 == 0)
		puts("WORK");
	else
		puts("ERREUR");
}

int main()
{
	char	*line;

	line = NULL;
	puts("\e[1;32m$minishel\033[1;34m=>\033[0m");
	while(1337)
	{
		get_next_line(&line);
		check_quote(line);
		puts("\n\e[1;32m$minishel\033[1;34m=>\033[0m");
		free(line);
		line = NULL;
	}
}